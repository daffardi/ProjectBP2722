package com.example.projectbp2722

class BukuModel (var image: Int, var title:String, var desc:String) {
}